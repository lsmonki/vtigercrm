<?php

/* 
* Copyright (C) www.vtiger.com. All rights reserved.
* @license Proprietary
*/

class Settings_ExtensionStore_ExtensionImport_View extends Settings_Vtiger_Index_View {

    public function __construct() {
        parent::__construct();
        $this->exposeMethod('searchExtension');
        $this->exposeMethod('index');
        $this->exposeMethod('detail');
        $this->exposeMethod('installationLog');
        $this->exposeMethod('oneClickInstall');
    }
    
    protected function getModelInstance() {
        if(!isset($this->modelInstance)){
            $this->modelInstance = Settings_ExtensionStore_Extension_Model::getInstance();
        }
        return $this->modelInstance;
    }

    public function process(Vtiger_Request $request) {
        $mode = $request->getMode();
        if (!empty($mode)) {
            $this->invokeExposedMethod($mode, $request);
            return;
        }

        $modelInstance = $this->getModelInstance();
        $EXTENSIONS = $modelInstance->getListings();
        $qualifiedModuleName = $request->getModule(false);

        $viewer = $this->getViewer($request);
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);
        $viewer->assign('EXTENSIONS', $EXTENSIONS);
        $viewer->assign('EXTENSIONS_AVAILABLE', (count($EXTENSIONS) > 0) ? true : false);
        $viewer->view('Index.tpl', $qualifiedModuleName);
    }

    /**
     * Function to get the list of Script models to be included
     * @param Vtiger_Request $request
     * @return <Array> - List of Vtiger_JsScript_Model instances
     */
    function getHeaderScripts(Vtiger_Request $request) {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();

        $jsFileNames = array(
            "libraries.jquery.jqueryRating",
            "libraries.jquery.boxslider.jqueryBxslider",
        );

        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
    }

    protected function index(Vtiger_Request $request) {
        $viewer = $this->getViewer($request);
        $qualifiedModuleName = $request->getModule(false);
        $modelInstance = $this->getModelInstance();
        $registrationStatus = $modelInstance->checkRegistration();

        if ($registrationStatus) {
            $pwdStatus = $modelInstance->passwordStatus();
            if (!$pwdStatus) {
                $sessionIdentifer = $modelInstance->getSessionIdentifier();
                $pwd = $_SESSION[$sessionIdentifer . '_password'];
                if (!empty($pwd)) {
                    $pwdStatus = true;
                }
            }
        }
        if ($registrationStatus && $pwdStatus && function_exists('_vtextnld')) {
            $customerProfile = $modelInstance->getProfile();
            $customerCardId = $customerProfile['CustomerCardId'];
            if (!empty($customerCardId)) {
                $customerCardDetails = $modelInstance->getCardDetails($customerCardId);
                $viewer->assign('CUSTOMER_CARD_INFO', $customerCardDetails);
            }
            $viewer->assign('CUSTOMER_PROFILE', $customerProfile);
        }
        
        if(class_exists('Settings_ExtensionStorePro_ExtnStorePro_Connector') && function_exists('_vtextnld')){
            $is_pro = true;
        }else{
            $is_pro = false;
        }

        $viewer->assign('PASSWORD_STATUS', $pwdStatus);
        $viewer->assign('IS_PRO', $is_pro);
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);
        $viewer->assign('EXTENSIONS_LIST', $modelInstance->getListings());
        $viewer->assign('REGISTRATION_STATUS', $registrationStatus);
        $viewer->view('Index.tpl', $qualifiedModuleName);
    }

    protected function searchExtension(Vtiger_Request $request) {
        $searchTerm = $request->get('searchTerm');
        $searchType = $request->get('type');
        $viewer = $this->getViewer($request);
        $qualifiedModuleName = $request->getModule(false);
        $modelInstance = $this->getModelInstance();
        $registrationStatus = $modelInstance->checkRegistration();
        
        if ($registrationStatus) {
            $pwdStatus = $modelInstance->passwordStatus();
            if (!$pwdStatus) {
                $sessionIdentifer = $modelInstance->getSessionIdentifier();
                $pwd = $_SESSION[$sessionIdentifer . '_password'];
                if (!empty($pwd)) {
                    $pwdStatus = true;
                }
            }
        }
        
        if(class_exists('Settings_ExtensionStorePro_ExtnStorePro_Connector') && function_exists('_vtextnld')){
            $is_pro = true;
        }else{
            $is_pro = false;
        }

        $viewer->assign('PASSWORD_STATUS', $pwdStatus);
        $viewer->assign('IS_PRO', $is_pro);
        $viewer->assign('REGISTRATION_STATUS', $registrationStatus);
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);
        $viewer->assign('EXTENSIONS_LIST', $modelInstance->findListings($searchTerm, $searchType));
        $viewer->view('ExtensionModules.tpl', $qualifiedModuleName);
    }

    protected function detail(Vtiger_Request $request) {
        $viewer = $this->getViewer($request);
        $qualifiedModuleName = $request->getModule(false);
        $extensionId = $request->get('extensionId');
        $moduleAction = $request->get('moduleAction'); //Import/Upgrade
        $modelInstance = $this->getModelInstance();
        
        $extensionDetail = $modelInstance->getExtensionListings($extensionId);
        $customerReviews = $modelInstance->getCustomerReviews($extensionId);
        $screenShots = $modelInstance->getScreenShots($extensionId);
        $authorInfo = $modelInstance->getListingAuthor($extensionId);
        $registrationStatus = $modelInstance->checkRegistration();

        if ($registrationStatus) {
            $pwdStatus = $modelInstance->passwordStatus();
            if (!$pwdStatus) {
                $sessionIdentifer = $modelInstance->getSessionIdentifier();
                $pwd = $_SESSION[$sessionIdentifer . '_password'];
                if (!empty($pwd)) {
                    $pwdStatus = true;
                }
            }
            $viewer->assign('PASSWORD_STATUS', $pwdStatus);
        }
        
        if(class_exists('Settings_ExtensionStorePro_ExtnStorePro_Connector') && function_exists('_vtextnld')){
            $is_pro = true;
        }else{
            $is_pro = false;
        }
        
        $viewer->assign('IS_PRO', $is_pro);
        $viewer->assign('MODULE_ACTION', $moduleAction);
        $viewer->assign('SCREEN_SHOTS', $screenShots);
        $viewer->assign('AUTHOR_INFO', $authorInfo);
        $viewer->assign('CUSTOMER_REVIEWS', $customerReviews);
        $viewer->assign('EXTENSION_DETAIL', $extensionDetail[$extensionId]);
        $viewer->assign('EXTENSION_ID', $extensionId);
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);
        $viewer->assign('REGISTRATION_STATUS', $registrationStatus);
        $viewer->view('Detail.tpl', $qualifiedModuleName);
    }

    protected function installationLog(Vtiger_Request $request) {
        $viewer = $this->getViewer($request);
        global $Vtiger_Utils_Log;
        $viewer->assign('VTIGER_UTILS_LOG', $Vtiger_Utils_Log);
        $Vtiger_Utils_Log = true;
        $qualifiedModuleName = $request->getModule(false);

        $extensionId = $request->get('extensionId');
        $targetModuleName = $request->get('targetModule');
        $moduleAction = $request->get('moduleAction');
        $modelInstance = $this->getModelInstance();

        $extensionModel = $modelInstance->getInstanceById($extensionId);
        if ($extensionModel) {
            $package = $extensionModel->getPackage();
            if ($package) {
                $importedModuleName = $package->getModuleName();
                $isLanguagePackage = $package->isLanguageType();

                if ($moduleAction === 'Upgrade') {
                    if (($isLanguagePackage && (trim($package->xpath_value('prefix')) == $targetModuleName)) || (!$isLanguagePackage && $importedModuleName === $targetModuleName)) {
                        $upgradeError = false;
                    }
                } else {
                    $upgradeError = false;
                }
                if (!$upgradeError) {
                    if (!$isLanguagePackage) {
                        $moduleModel = Vtiger_Module_Model::getInstance($importedModuleName);
                        $viewer->assign('MODULE_EXISTS', ($moduleModel) ? true : false);
                        $viewer->assign('MODULE_DIR_NAME', '../modules/' . $importedModuleName);

                        if (!$extensionModel->isUpgradable()) {
                            $viewer->assign('SAME_VERSION', true);
                        }
                    }
                    $moduleType = $package->type();
                    $fileName = $extensionModel->getFileName();
                } else {
                    $viewer->assign('ERROR', true);
                    $viewer->assign('ERROR_MESSAGE', vtranslate('LBL_INVALID_FILE', $qualifiedModuleName));
                }
            } else {
                $viewer->assign('ERROR', true);
                $viewer->assign('ERROR_MESSAGE', vtranslate('LBL_INVALID_FILE', $qualifiedModuleName));
            }
        } else {
            $viewer->assign('ERROR', true);
            $viewer->assign('ERROR_MESSAGE', vtranslate('LBL_INVALID_FILE', $qualifiedModuleName));
        }

        if ($extensionId) {
            if ($moduleAction !== 'Upgrade') {
                $extensionModel->installTrackDetails();
            }
            if (strtolower($moduleType) === 'language') {
                $package = new Vtiger_Language();
            } else {
                $package = new Vtiger_Package();
            }

            $viewer->assign('MODULE_ACTION', $moduleAction);
            $viewer->assign('MODULE_PACKAGE', $package);
            $viewer->assign('TARGET_MODULE_INSTANCE', Vtiger_Module_Model::getInstance($targetModuleName));
            $viewer->assign('MODULE_FILE_NAME', Settings_ExtensionStore_Extension_Model::getUploadDirectory() . '/' . $fileName);
        } else {
            $viewer->assign('ERROR', true);
            $viewer->assign('ERROR_MESSAGE', vtranslate('LBL_INVALID_MODULE_INFO', $qualifiedModuleName));
        }
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);
        $viewer->view('InstallationLog.tpl', $qualifiedModuleName);
    }

    protected function oneClickInstall(Vtiger_Request $request) {
        $viewer = $this->getViewer($request);
        global $Vtiger_Utils_Log;
        $viewer->assign('VTIGER_UTILS_LOG', $Vtiger_Utils_Log);
        $Vtiger_Utils_Log = true;
        $upgradeError = true;
        $qualifiedModuleName = $request->getModule(false);
        $extensionId = $request->get('extensionId');
        $moduleAction = $request->get('moduleAction'); //Import/Upgrade
        $trail = $request->get('trail');
        $modelInstance = $this->getModelInstance();
        $extensionModel = $modelInstance->getInstanceById($extensionId, $trail);

        if ($extensionModel) {
            $package = $extensionModel->getPackage();
            if ($package) {
                $importedModuleName = $package->getModuleName();
                $isLanguagePackage = $package->isLanguageType();

                if ($moduleAction === 'Upgrade') {
                    $targetModuleName = $request->get('extensionName');
                    if (($isLanguagePackage && (trim($package->xpath_value('prefix')) == $targetModuleName)) || (!$isLanguagePackage && $importedModuleName === $targetModuleName)) {
                        $upgradeError = false;
                    }
                } else {
                    $upgradeError = false;
                }
                if (!$upgradeError) {
                    if (!$isLanguagePackage) {
                        $moduleModel = Vtiger_Module_Model::getInstance($importedModuleName);

                        if (!$extensionModel->isUpgradable()) {
                            $viewer->assign('SAME_VERSION', true);
                        }
                    }

                    $moduleType = $packageType = $package->type();
                    $fileName = $extensionModel->getFileName();
                } else {
                    $viewer->assign('ERROR', true);
                    $viewer->assign('ERROR_MESSAGE', vtranslate('LBL_INVALID_FILE', $qualifiedModuleName));
                }
            } else {
                $viewer->assign('ERROR', true);
                $viewer->assign('ERROR_MESSAGE', vtranslate('LBL_INVALID_FILE', $qualifiedModuleName));
            }
        } else {
            $viewer->assign('ERROR', true);
            $viewer->assign('ERROR_MESSAGE', vtranslate('LBL_INVALID_FILE', $qualifiedModuleName));
        }

        if ($extensionId) {
            if ($moduleAction !== 'Upgrade') {
                $extensionModel->installTrackDetails();
            }
            if (strtolower($moduleType) === 'language') {
                $package = new Vtiger_Language();
            } else {
                $package = new Vtiger_Package();
            }

            $viewer->assign('MODULE_ACTION', $moduleAction);
            $viewer->assign('MODULE_PACKAGE', $package);
            $viewer->assign('TARGET_MODULE_INSTANCE', Vtiger_Module_Model::getInstance($targetModuleName));
            $viewer->assign('MODULE_FILE_NAME', Settings_ExtensionStore_Extension_Model::getUploadDirectory() . '/' . $fileName);
        } else {
            $viewer->assign('ERROR', true);
            $viewer->assign('ERROR_MESSAGE', vtranslate('LBL_INVALID_MODULE_INFO', $qualifiedModuleName));
        }
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);
        $viewer->view('InstallationLog.tpl', $qualifiedModuleName);
    }
}
