<?php

/*
 * Copyright (C) www.vtiger.com. All rights reserved.
 * @license Proprietary
 */

class Settings_ExtensionStore_Basic_Action extends Settings_Vtiger_IndexAjax_View {

    protected $modelInstance;

    function __construct() {
        parent::__construct();
        $this->exposeMethod('updateCardDetails');
        $this->exposeMethod('postReview');
        $this->exposeMethod('getDateString');
        $this->exposeMethod('uninstallExtension');
        $this->exposeMethod('registerAccount');
        $this->exposeMethod('updateTrailMode');
    }

    function process(Vtiger_Request $request) {
        $mode = $request->getMode();
        if (!empty($mode)) {
            echo $this->invokeExposedMethod($mode, $request);
            return;
        }
    }

    protected function getModelInstance() {
        if(!isset($this->modelInstance)){
            $this->modelInstance = Settings_ExtensionStore_Extension_Model::getInstance();
        }
        return $this->modelInstance;
    }

    protected function updateCardDetails(Vtiger_Request $request) {
        $number = (int) $request->get('cardNumber');
        $expmonth = (int) $request->get('expMonth');
        $expyear = (int) $request->get('expYear');
        $cvc = (int) $request->get('cvccode');
        $customerId = (int) $request->get('customerId');
        $customerCardId = (int) $request->get('customerCardId');
        $modelInstance = $this->getModelInstance();

        if (empty($customerCardId)) {
            $result = $modelInstance->createCard($number, $expmonth, $expyear, $cvc);
        } else {
            $result = $modelInstance->updateCard($number, $expmonth, $expyear, $cvc, $customerId);
        }
        $response = new Vtiger_Response();
        if ($result['success'] != 'true') {
            $response->setError('', $result['error']);
        } else {
            $response->setResult($result['result']);
        }
        $response->emit();
    }

    protected function postReview(Vtiger_Request $request) {
        $listing = $request->get('listing');
        $comment = $request->get('comment');
        $rating = $request->get('rating');
        $modelInstance = $this->getModelInstance();
        
        $result = $modelInstance->postReview($listing, $comment, $rating);
        $response = new Vtiger_Response();
        $response->setResult($result['result']);
        $response->emit();
    }

    protected function getDateString(Vtiger_Request $request) {
        $date = $request->get('date');
        $dateString = Vtiger_Util_Helper::formatDateTimeIntoDayString($date);
        $response = new Vtiger_Response();
        $response->setResult($dateString);
        $response->emit();
    }

    protected function uninstallExtension(Vtiger_Request $request) {
        $extensionName = $request->get('extensionName');
        $extensionInstance = Vtiger_Module_Model::getInstance($extensionName);
        $extensionInstance->delete();

        //Remove extension files
        global $root_directory;
        $pathToExtensionLayouts = $root_directory . "layouts/vlayout/modules/$extensionName";
        shell_exec("rm -rf $pathToExtensionLayouts");

        $pathToExtensionModule = $root_directory . "modules/$extensionName";
        shell_exec("rm -rf $pathToExtensionModule");

        $response = new Vtiger_Response();
        $response->setResult(array('success' => true, 'message' => 'extension deleted'));
        $response->emit();
    }

    protected function registerAccount(Vtiger_Request $request) {
        $options = array();
        $userAction = $request->get('userAction');
        $options['emailaddress'] = $request->get('emailaddress');
        $options['password'] = $request->get('password');
        $modelInstance = $this->getModelInstance();
        
        if ($userAction == 'signup') {
            $options['firstName'] = $request->get('firstName');
            $options['lastName'] = $request->get('lastName');
            $options['companyName'] = $request->get('companyName');
            $options['confirmPassword'] = $request->get('confirmPassword');
            $profieInfo = $modelInstance->signup($options);
        } elseif ($userAction == 'login') {
            $options['savePassword'] = $request->get('savePassword');
            $options['password'] = md5($options['password']);
            $profieInfo = $modelInstance->login($options);
        } elseif ($userAction == 'register') {
            $options['savePassword'] = $request->get('savePassword');
            $options['password'] = $options['password'];
            $profieInfo = $modelInstance->register($options);
        }
        $response = new Vtiger_Response();
        if ($profieInfo['success'] != 'true') {
            $response->setError('', $profieInfo['error']);
        } else {
            $response->setResult($profieInfo['result']);
        }
        $response->emit();
    }

    protected function updateTrailMode(Vtiger_Request $request) {
        $response = new Vtiger_Response();
        $importedModuleName = $request->get('extensionName');
        $trail = $request->get('trail');
        $db = PearDatabase::getInstance();
        $db->pquery('UPDATE vtiger_tab SET trail = ? WHERE name = ?', array($trail, $importedModuleName));
        $response->setResult(array('success' => true, 'message' => 'Extension Store Installed'));
        $response->emit();
    }

}
