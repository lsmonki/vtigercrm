/*
 * Copyright (C) www.vtiger.com. All rights reserved.
 * @license Proprietary
 */

jQuery.Class("ExtensionStore_ExtensionStore_Js", {}, {
    
    /**
     * Function to register events for banner
     */
    registerEventsForBanner : function(){
        jQuery('.bxslider').bxSlider({
            mode: 'fade',
            captions: true,
            auto: true,
            speed: 200,
            pause: 2000,
            onSlideBefore : function(){
                jQuery('.bx-viewport').css({'height': '150px', 'overflow': 'hidden'});
            }
        });
    },
    
    /**
     * Function to get promotions from market place
     */
    getPromotionsFromMarketPlace : function(){
        var thisInstance = this;
        var params = {
            'module': 'ExtensionStore',
            'view': 'Listings',
            'mode': 'getPromotions'
        };
        var progressIndicatorElement = jQuery.progressIndicator({
            'position': 'html',
            'blockInfo': {
                'enabled': true
            }
        });
        AppConnector.request(params).then(
                function(data) {
                    progressIndicatorElement.progressIndicator({'mode': 'hide'});
                    if(typeof data != 'undefined'){
                        jQuery('.marketPlaceBanner').html(data);
                        thisInstance.registerEventsForBanner();
                    }else{
                        jQuery('.togglePromotion').trigger('click');
                    }
                },
                function(error) {
                    progressIndicatorElement.progressIndicator({'mode': 'hide'});
                }
        );
    },
    
    registerEventsForTogglePromotion : function() {
        var thisInstance = this;
        jQuery('.togglePromotion').on('click', function(e){
            var element = jQuery(e.currentTarget);
            var bannerContainer = jQuery(".banner-container");
            
            if(element.hasClass('up')){
                 bannerContainer.slideUp();
                 element.find('.icon-chevron-up').addClass('hide');
                 element.find('.icon-chevron-down').removeClass('hide');
                 element.addClass('down').removeClass('up');
                 //Caching closed date value
                 var date = new Date();
                 var currentDate = date.getDate()+":"+(date.getMonth()+1)+":"+date.getUTCFullYear();
                 app.cacheSet('ExtensionStore_Promotion_CloseDate', currentDate);
            }else if(element.hasClass('down')){
                bannerContainer.slideDown();
                if(bannerContainer.find('img').length <= 0){
                    thisInstance.getPromotionsFromMarketPlace();
                }
                element.find('.icon-chevron-down').addClass('hide');
                element.find('.icon-chevron-up').removeClass('hide');
                element.addClass('up').removeClass('down');
                app.cacheClear('ExtensionStore_Promotion_CloseDate');
            }
        });
    },
    
    registerEvents: function() {
        var thisInstance = this;
        var moduleName = app.getModuleName();
        var promotionClosedDate = app.cacheGet('ExtensionStore_Promotion_CloseDate', null);
        var getPromotion = false;
        if(promotionClosedDate == null){
            getPromotion = true;
        }else if(promotionClosedDate.length > 0){
           var closedDate = promotionClosedDate.split(":"); 
           var closedOn = new Date(parseInt(closedDate[2]), parseInt(closedDate[1]), parseInt(closedDate[0]));
           var currentDate = new Date();
           var diff = currentDate - closedOn;
           var days = diff/1000/60/60/24;
           if(days >= 7){
               getPromotion = true;
           }else {
               getPromotion = false;
           }
        }
        
        if ((moduleName == "Home") && getPromotion) {
            thisInstance.getPromotionsFromMarketPlace();
        }else if((moduleName == "Home") && !getPromotion){
            jQuery('.togglePromotion').find('.icon-chevron-up').addClass('hide');
            jQuery('.togglePromotion').find('.icon-chevron-down').removeClass('hide');
            jQuery('.togglePromotion').addClass('down').removeClass('up');
        }
        thisInstance.registerEventsForTogglePromotion();
    }
});

jQuery(document).ready(function() {
    var moduleName = app.getModuleName();
    if (moduleName == "Home") {
        var instance = new ExtensionStore_ExtensionStore_Js();
        instance.registerEvents();
    }
});