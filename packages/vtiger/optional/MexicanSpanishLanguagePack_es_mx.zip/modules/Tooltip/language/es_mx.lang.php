<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * Portions created by jpl tsolucio,s.l. are Copyright (C) jpl tsolucio, s.l.
 * All Rights Reserved.
*  Author       : Francisco Hernandez Odin Consultores www.odin.mx 
 ********************************************************************************/

$mod_strings = Array (
'Tooltip' => 'Ayuda rápida',
'LBL_TOOLTIP_MANAGEMENT'=>'Administración de Ayudas',
'LBL_TOOLTIP_MANAGEMENT_DESCRIPTION'=>'Administra los mensajes de ayuda aqui',
'LBL_TOOLTIP_HELP_TEXT'=>'Selecciona los campos a mostrar como ayuda',
'LBL_FIELDS_IN'=>'Campos en',
'LBL_FIELD'=>'Campo',
);

?>
