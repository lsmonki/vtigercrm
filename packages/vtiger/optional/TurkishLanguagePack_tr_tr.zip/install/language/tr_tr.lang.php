<?php
/***********************************************************
*  Module       : Installation
*  Language     : Turkce
*  Version      : 5.1.0
*  Created Date : 2009-06-23 21:36:13 
*  Last change  : 2009-09-08 17:22:04
*  Author       : zeitin
*  License      : GPL

***********************************************************/

$optionalModuleStrings = array(
		'CustomerPortal_description'=>'Musteri Portali Arabirimi',
		'FieldFormulas_description'=>'Alan formulleri parametreler',
		'RecycleBin_description'=>'Cop kutusu ile silinmisleri geri getirme',
		'Tooltip_description'=>'Arac cubugu aciklamalari',
		'Webforms_description'=>'Kolay form hazirlama ozelligi'
	);
?>