<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$mod_strings = Array(
'RecycleBin' => 'Çöp Kutusu',
'MSG_EMPTY_RB_CONFIRMATION'=>'Veritabanınızdaki silinmiş kayıtları sonsuza dek kalıcı olarak yoketmek istediğinizden emin misiniz?',
'LBL_SELECT_MODULE'=>'Modül Seçin',
'LBL_EMPTY_MODULE'=>'Bu modülde geri getirilebilecek kayıt bulunmadı',
'LBL_MASS_RESTORE'=>'Geri Getir',
'LBL_EMPTY_RECYCLEBIN'=>'Çöp Kutusunu Boşalt',
'LNK_RESTORE'=>'geri getir',
'LBL_NO_PERMITTED_MODULES'=>'İzin verilen modül yok',
);

?>