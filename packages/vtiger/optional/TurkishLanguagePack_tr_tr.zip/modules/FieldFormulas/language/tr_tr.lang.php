<?php
/*+*******************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ******************************************************************************/
$mod_strings = Array (
'FieldFormulas' => 'Alan Formülleri',
'LBL_FIELDFORMULAS' => 'Alan Formülleri',
'LBL_FIELDFORMULAS_DESCRIPTION' => 'Özel alanlara hesaplamalar ekle',
'LBL_FIELDS' => 'Alanlar',
'LBL_FUNCTIONS' => 'Fonksiyonlar',
'LBL_FIELD' => 'Alan',
'LBL_EXPRESSION' => 'Denklem',
'LBL_SETTINGS' => 'Ayarlar',
'LBL_NEW_FIELD_EXPRESSION_BUTTON' => 'Yeni Alan Denklemi',
'LBL_EDIT_EXPRESSION' => 'Denklemi Düzenle',
'LBL_MODULE_INFO' => 'Formülleri tanımlanmış ',
'NEED_TO_ADD_A' =>'Karakter dizisi veya sayısal tip eklemelisiniz ',
'LBL_CUSTOM_FIELD' =>'Özel Alan',
'LBL_CHECKING'=>'Kontrol ediyor...',
'LBL_SELECT_ONE_DOTDOTDOT'=>'Birini Seçin...',
'LBL_TARGET_FIELD'=>'Hedef Alan',
'LBL_DELETE_EXPRESSION_CONFIRM'=>'Denklemi silmek istediğinize emin misiniz?',
'LBL_EXAMPLES'=>'Örnekler',
'LBL_USE_FIELD_VALUE_DASHDASH'=>'-- Alan Değerinin kullan --',
'LBL_USE_FUNCTION_DASHDASH'=>'-- Fonksiyon kullan --',
);

?>