<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'Webforms' => 'Netformları',
'LBL_SUCCESS' => 'vtiger CRMe eklendi.',
'LBL_FAILURE' => 'vtiger CRMe ekleme başarısız.',
'LBL_ERROR_CODE' => 'Hata Kodu',
'LBL_ERROR_MESSAGE' => 'Hata Mesajı',

//Internationalization for odu12
'LBL_WEBFORM_NAME'=>'Adı Webform',
'LBL_DESCRIPTION'=>'tanım',
'LBL_MODULE'=>'modül',
'LBL_RETURNURL'=>'URL dön',
'LBL_ACTION'=>'eylem',
'LBL_ASSIGNED_TO'=>'atanan',
'LBL_EDIT'=>'düzenle',
'LBL_DELETE'=>'sil',
'LBL_SOURCE'=>'Formu göster',
'LBL_MODULE_INFORMATION'=>'Webforms Bilgi',
'LBL_FIELD_INFORMATION'=>'Alan Bilgisi',
'LBL_ENABLE'=>'etkinleştir',
'LBL_ENABLED'=>'Etkin',
'LBL_FIELDLABEL'=>'Alan Adı',
'LBL_DEFAULT_VALUE'=>'değer geçersiz kılma',
'LBL_NEUTRALIZEDFIELD'=>'Webforms Referans Alan',
'LBL_PUBLICID'=>'kamu Kimliği',
'LBL_NO_WEBFORM'=>'Hiçbir Webforms bulundu!',
'LBL_CREATE_WEBFORM'=>'Bir Webform oluşturma',
'LBL_POSTURL'=>'URL Gönder',
'LBL_REQUIRED'=>'Gerekli',
'LBL_STATUS'=>'Durumu',
'LBL_EMBED_MSG'=>'Web sitenize aşağıdaki formu katıştırma',
'LBL_CANCEL'=>'iptal',
'LBL_SAVE'=>'Kaydet',
'LBL_SELECT_VALUE'=>'--Değer Seç--',
'LBL_DUPLICATE_NAME' => 'Aynı adı var olan Webform',
'ERR_CREATE_WEBFORM' => 'Webform oluşturma başarısız oldu',
'LBL_SELECT_USER' => 'Kullanıcı Seç',
'LBL_CREATE_NEW_WEBFORM_NOW' => 'Bir Webform oluşturma yapabilirsiniz. Bu linke tıklayın:'
);

?>
