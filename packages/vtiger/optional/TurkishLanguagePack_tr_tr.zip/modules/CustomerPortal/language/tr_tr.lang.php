<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'Müşteri Portali',
'LBL_BASIC_SETTINGS'=>'Temel Ayarlar',
'LBL_ADVANCED_SETTINGS'=>'Gelişmiş Ayarlar',
'LBL_MODULE'=>'Modül',
'LBL_VIEW_ALL_RECORD'=>'Tüm İlişkili Kayıtları Görüntüle ?',
'YES'=>'Evet',
'NO'=>'Hayır',
'LBL_USER_DESCRIPTION'=>'Yukarıda seçilen kullanıcının profiline göre Müşteri Portalinde görünecek alanlar belirlenir. Müşteri Portakinde görünecek alanları açıp kapatabilirsiniz.',
'SELECT_USERS'=>'Kullanıcıları Seç',				
'LBL_DISABLE'=>'Etkisiz Kıl',
'LBL_ENABLE' =>'Etkinleştir',
'Module' => 'Modül',
'Sequence' =>'Sıra',
'Visible'=>'Görünür'

);

?>
