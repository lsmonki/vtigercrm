<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
	'LBL_ACTIVE' => 'Active',
	'LBL_INACTIVE' => 'InActive',
	'LBL_STATUS' => 'Status',
	'LBL_SCHEDULER' => 'Scheduler',
	'LBL_SETTINGS' => 'Settings',
	'LBL_FREQUENCY'=> 'Frequency',
	'LBL_HOURMIN' => '(H:M)',
	'LAST_START'=>'Last Scan Started',
	'LAST_END'=>'Last Scan Ended',
	'LBL_SEQUENCE'=>'Sequence',
	'LBL_TOOLS' =>'Tools',
	'LBL_DAYS'=>'Days',
	'LBL_HOURS'=>'Hours',
	'LBL_MINS'=>'Mins',
	'LBL_RUNNING'=>'Running',
	'LBL_MINIMUM_FREQUENCY'=>'Frequency of any cron job  configured should be greater than',
	'LBL_SECONDS'=>'sec ago',
	'LBL_MINUTES'=>'min(s) ago',
	'LBL_HOURS'=>'hr(s) ago',
	'LBL_DAYS'=>'day(s) ago',
	'LBL_MONTHS'=>'month(s) ago',
	'LBL_YEARS'=>'year(s) ago',
);
?>