<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
        'LBL_ACTIVE' => 'Active',
        'LBL_INACTIVE' => 'InActive',
        'LBL_STATUS' => 'Status',
        'LBL_SCHEDULER' => 'Scheduler',
        'LBL_SETTINGS' => 'Settings',
        'LBL_FREQUENCY'=> 'Frequency',
        'LBL_HOURMIN' => '(H:M)',
        'LAST_START'=>'Last Scan Started',
        'LAST_END'=>'Last Scan Ended',
        'LBL_SEQUENCE'=>'Sequence',
        'LBL_TOOLS' =>'Tools',
        'LBL_DAYS'=>'Days',
        'LBL_HOURS'=>'Hours',
        'LBL_MINS'=>'Mins',
        'LBL_RUNNING'=>'Running',
        'LBL_MINIMUM_FREQUENCY'=>'Frequency of any cron job in Ondemand should be greater than 15 mins',
		'LBL_SECONDS'=>'sec ago',
		'LBL_MINUTES'=>'mins ago',
		'LBL_HOURS'=>'hrs ago',
		'LBL_DAYS'=>'days ago',
		'LBL_MONTHS'=>'months ago',
		'LBL_Years'=>'years ago',
);
?>