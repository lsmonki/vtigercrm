<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
* ("License"); You may not use this file except in compliance with the License
* The Original Code is:  vtiger CRM Open Source
* The Initial Developer of the Original Code is vtiger.
* Portions created by vtiger are Copyright (C) vtiger.
* Vertaald door: Weltvree.org  www.weltevree.org
********************************************************************************/

$mod_strings = Array(
	'Asterisk' => 'Sterretje',
	'LBL_ASTERISK_INFORMATION' => 'STERRETJE Informatie',

	'Call From'=>'Oproep Van',
	'Call To'=>'Oproer Naar',
	'Time Of Call'=>'Tijdstip van Oproep',
);

?>
