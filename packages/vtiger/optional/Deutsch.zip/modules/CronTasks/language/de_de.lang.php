<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
        'LBL_ACTIVE' => 'Activ',
        'LBL_INACTIVE' => 'Inactiv',
        'LBL_STATUS' => 'Status',
        'LBL_SCHEDULER' => 'Planer',
        'LBL_SETTINGS' => 'Einstellungen',
        'LBL_FREQUENCY'=> 'Frequenz',
        'LBL_HOURMIN' => '(H:M)',
        'LAST_START'=>'letzte Prüfung gestartet',
        'LAST_END'=>'letzte Prüfung beendet',
        'LBL_SEQUENCE'=>'Sequenz',
        'LBL_TOOLS' =>'Werkzeuge',
        'LBL_DAYS'=>'Tage',
        'LBL_HOURS'=>'Stunden',
        'LBL_MINS'=>'Minuten',
        'LBL_RUNNING'=>'Running',
        'LBL_MINIMUM_FREQUENCY'=>'Die Frequenz von Cronjobs ind der "OnPremise" Version sollte größer 15 Minuten sein',
		'LBL_SECONDS'=>'Sekunden zuvor',
		'LBL_MINUTES'=>'Minuten zuvor',
		'LBL_HOURS'=>'Stunden zuvor',
		'LBL_DAYS'=>'Tage zuvor',
		'LBL_MONTHS'=>'Monate zuvor',
		'LBL_YEARS'=>'Jahre zuvor',
);
?>