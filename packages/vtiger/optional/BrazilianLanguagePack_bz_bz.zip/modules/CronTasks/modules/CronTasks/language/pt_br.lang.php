<?php
//Contributor(s): Valmir Carlos Trindade/Translate to Brazilian Portuguese| 03/03/2012 |Curitiba/Paraná/Brasil.|www.ttcasolucoes.com.br
$mod_strings = Array (
        'LBL_ACTIVE' => 'Ativo',
        'LBL_INACTIVE' => 'Inativo',
        'LBL_STATUS' => 'Status',
        'LBL_SCHEDULER' => 'Agendador',
        'LBL_SETTINGS' => 'Configurações',
        'LBL_FREQUENCY'=> 'Frequência',
        'LBL_HOURMIN' => '(H:M)',
        'LAST_START'=>'Início Último Verificação',
        'LAST_END'=>'Final Última Verificação',
        'LBL_SEQUENCE'=>'Sequência',
        'LBL_TOOLS' =>'Ferramentas',
        'LBL_DAYS'=>'Dias',
        'LBL_HOURS'=>'Horas',
        'LBL_MINS'=>'Minutos',
        'LBL_RUNNING'=>'Executando',
        'LBL_MINIMUM_FREQUENCY'=>'A frequência de qualquer tarefa agendada deve ser superior a 15 minutos',
		'LBL_SECONDS'=>'seg antes',
		'LBL_MINUTES'=>'min antes',
		'LBL_HOURS'=>'hrs antes',
		'LBL_DAYS'=>'dias antes',
		'LBL_MONTHS'=>'meses antes',
		'LBL_YEARS'=>'anos antes',
);
?>
