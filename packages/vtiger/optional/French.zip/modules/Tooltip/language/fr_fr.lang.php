<?php
/***********************************************************
*  Module       : Tooltips
*  Language     : Francais
*  Version      : 5.1.0 RC
*  Created Date : 2009-06-23 21:36:13 
*  Last change  : 2009-07-21 00:49:17
*  Author       : french-vtiger.fr 
*  License      : GPL

***********************************************************/

$mod_strings = Array (
'Tooltip' => 'Infobulles',
'LBL_TOOLTIP_MANAGEMENT'=>'Gestion des infobulles',
'LBL_TOOLTIP_MANAGEMENT_DESCRIPTION'=>'G&eacute;rer les infobulles',
'LBL_FIELDS_IN'=>'Champs contenant',
'LBL_TOOLTIP_HELP_TEXT'=>'S&eacute;lectionnez les champs pour lesquels vous voulez ajouter des infobulles',
'LBL_FIELD'=>'Champs',

);

?>
