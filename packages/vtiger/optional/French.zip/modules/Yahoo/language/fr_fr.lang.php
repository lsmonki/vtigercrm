<?php
/***********************************************************
*  Module       : Yahoo
*  Language     : French
*  Version      : 5.3.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr

***********************************************************/

$mod_strings = Array(
	'LBL_MODULE_NAME' => 'Compte',
	'LBL_MODULE_TITLE' => 'Compte: Accueil',
	'LBL_SEARCH_FORM_TITLE' => 'Rechercher compte',
	'LBL_LIST_FORM_TITLE' => 'Liste comptes',
	'LBL_NEW_FORM_TITLE' => 'Nouveau compte',
	'ERR_DELETE_RECORD' => 'Une référence doit être spécifiée pour supprimer ce compte.',
);
?>