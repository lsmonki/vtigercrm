<?php
/***********************************************************
*  Module       : Systems
*  Language     : French
*  Version      : 5.4.0 
*  License      : GPL
*  Author       : ABOnline solutions http://www.vtiger-crm.fr
***********************************************************/

$mod_strings = Array(
	'LBL_SYSTEM_CONFIG' => 'Configuration système',
);

?>