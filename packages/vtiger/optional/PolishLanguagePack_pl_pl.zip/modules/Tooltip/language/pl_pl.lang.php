<?php
 /*+********************************************************************************
 * Terms & Conditions are placed on the: http://vtiger.com.pl
 ********************************************************************************
 *  Language		: Język Polski
 *  Vtiger Version	: 5.4.x
 *	Pack Version	: 1.13
 *  Author          : OpenSaaS Sp. z o.o. 
 *  Licence			: GPL
 *  Help/Email      : bok@opensaas.pl                                                                                                                 
 *  Website         : www.vtiger.com.pl, www.opensaas.pl
 ********************************************************************************+*/
$mod_strings = Array (
'Tooltip' => 'Podpowiedzi',
'LBL_TOOLTIP_MANAGEMENT'=>'Podpowiedzi',
'LBL_TOOLTIP_MANAGEMENT_DESCRIPTION'=>'Edycja zawartości podpowiedzi',
'LBL_FIELDS_IN'=>'Pola w',
'LBL_TOOLTIP_HELP_TEXT'=>'Wybierz pola które będą wyświetlały się w podpowiedzi',
'LBL_FIELD'=>'Pole',
);
?>