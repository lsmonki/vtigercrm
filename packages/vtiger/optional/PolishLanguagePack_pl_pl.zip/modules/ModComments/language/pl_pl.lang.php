<?php
 /*+********************************************************************************
 * Terms & Conditions are placed on the: http://vtiger.com.pl
 ********************************************************************************
 *  Language		: Język Polski
 *  Vtiger Version	: 5.4.x
 *	Pack Version	: 1.13
 *  Author          : OpenSaaS Sp. z o.o. 
 *  Licence			: GPL
 *  Help/Email      : bok@opensaas.pl                                                                                                                 
 *  Website         : www.vtiger.com.pl, www.opensaas.pl
 ********************************************************************************+*/
$mod_strings = Array (
'ModComments' => 'Komentarze',
'SINGLE_ModComments' => 'Komentarze',
'LBL_MODCOMMENTS_INFORMATION' => 'Komentarze i notatki',
'LBL_OTHER_INFORMATION' => ' Pozostałe Informacje ',
'LBL_CUSTOM_INFORMATION' => 'Informacje dodatkowe',
'Assigned To' => 'Przydzielone do',
'Created Time' => 'Czas utworzenia',
'Modified Time' => 'Czas modyfikacji',
'Comment' => 'Komentarz',
'Comments' => 'Komentarze',
'Related To' => 'Powiązane z',
'Creator' => 'Utworzył',
'Related To Comments' => 'Powiązany komentarz',
'LBL_ADD_COMMENT' => 'Dodaj komentarz',
'LBL_AUTHOR' => 'Autor',
'LBL_ON' => 'włącz',
'LBL_MINE' => 'Moje komentarze',
'LBL_LAST5'=> 'Ostatnie 5',
'Comments Information'=>'Komentarze',
'ModComments ID'=>'ID Komentarza',
);
?>
