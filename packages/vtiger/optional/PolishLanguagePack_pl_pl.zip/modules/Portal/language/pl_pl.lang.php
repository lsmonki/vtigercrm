<?php
 /*+********************************************************************************
 * Terms & Conditions are placed on the: http://vtiger.com.pl
 ********************************************************************************
 *  Language		: Język Polski
 *  Vtiger Version	: 5.4.x
 *	Pack Version	: 1.13
 *  Author          : OpenSaaS Sp. z o.o. 
 *  Licence			: GPL
 *  Help/Email      : bok@opensaas.pl                                                                                                                 
 *  Website         : www.vtiger.com.pl, www.opensaas.pl
 ********************************************************************************+*/
$mod_strings = Array(
'LBL_BOOKMARKED_URL'=>"Dodane do Zakładek",
'LBL_MANAGE_BOOKMARKS'=>'Porządkowanie Zakładek',
'LBL_BOOKMARK_LIST'=>'Lista Zakładek',
'LBL_MY_BOOKMARKS' => 'Moje Zakładki',
'LBL_NEW_BOOKMARK' => 'Nowa Zakładka',
'LBL_BOOKMARK' => 'Zakładka',
'LBL_NAME' => 'Nazwa :',
'LBL_URL' => 'URL:',
'LBL_ADD' => 'Dodaj',
'LBL_SNO'=>'#',
'LBL_BOOKMARK_NAME_URL'=>'Nazwa Zakładki &amp; URL',
'LBL_TOOLS'=>'Narzędzia',
'LBL_MANAGE_SITES'=>'Zarządzanie Stronami',
'LBL_MY_SITES'=>'Moje Strony WWW',
'LBL_SET_DEFAULT_BUTTON'=>'Ustaw jako Domyślna',
);
?>