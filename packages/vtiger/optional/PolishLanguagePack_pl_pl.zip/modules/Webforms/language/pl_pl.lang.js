 /*+********************************************************************************
 * Terms & Conditions are placed on the: http://vtiger.com.pl
 ********************************************************************************
 *  Language		: Język Polski
 *  Vtiger Version	: 5.4.x
 *	Pack Version	: 1.13
 *  Author          : OpenSaaS Sp. z o.o. 
 *  Licence			: GPL
 *  Help/Email      : bok@opensaas.pl                                                                                                                 
 *  Website         : www.vtiger.com.pl, www.opensaas.pl
 ********************************************************************************+*/

var webforms_alert_arr = {
	'LBL_MADATORY_FIELDS' : 'Proszę wprowadzić wartość w polach obowiązkowych',
	'LBL_DELETE_MSG' : 'Czy na pewno chcesz usunąć formularz www?',
	'LBL_DUPLICATE_NAME' : 'Formularz już istnieje'
};