<?php
 /*+********************************************************************************
 * Terms & Conditions are placed on the: http://vtiger.com.pl
 ********************************************************************************
 *  Language		: Język Polski
 *  Vtiger Version	: 5.4.x
 *	Pack Version	: 1.13
 *  Author          : OpenSaaS Sp. z o.o. 
 *  Licence			: GPL
 *  Help/Email      : bok@opensaas.pl                                                                                                                 
 *  Website         : www.vtiger.com.pl, www.opensaas.pl
 ********************************************************************************+*/
$mod_strings = Array(
'RecycleBin' => 'Kosz',
'MSG_EMPTY_RB_CONFIRMATION'=>'Czy jesteś pewien, że chcesz usunąć wybrane rekordy całkowicie z bazy? / operacja nieodwracalna /',
'LBL_SELECT_MODULE'=>'Wybierz Moduł',
'LBL_EMPTY_MODULE'=>'W module nie znaleziono wpisów do przywrócenia: ',
'LBL_MASS_RESTORE'=>'Przywracanie',
'LBL_EMPTY_RECYCLEBIN'=>'Opróźnij kosz',
'LNK_RESTORE'=>'przywróć',
'LBL_NO_PERMITTED_MODULES'=>'Brak uprawnień do modułu',
);
?>