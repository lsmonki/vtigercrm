 /*+********************************************************************************
 * Terms & Conditions are placed on the: http://vtiger.com.pl
 ********************************************************************************
 *  Language		: Język Polski
 *  Vtiger Version	: 5.4.x
 *	Pack Version	: 1.13
 *  Author          : OpenSaaS Sp. z o.o. 
 *  Licence			: GPL
 *  Help/Email      : bok@opensaas.pl                                                                                                                 
 *  Website         : www.vtiger.com.pl, www.opensaas.pl
 ********************************************************************************+*/

var mod_alert_arr = {       
	SELECT_ATLEAST_ONE_ENTITY:'Proszę wybrać conajmniej jeden rekord',
	MSG_RESTORE_CONFIRMATION:'Czy napewno przywrócić wybrane rekordy?'
};