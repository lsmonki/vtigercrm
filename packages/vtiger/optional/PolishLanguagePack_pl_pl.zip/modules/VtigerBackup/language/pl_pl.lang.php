<?php
 /*+********************************************************************************
 * Terms & Conditions are placed on the: http://vtiger.com.pl
 ********************************************************************************
 *  Language		: Język Polski
 *  Vtiger Version	: 5.4.x
 *	Pack Version	: 1.13
 *  Author          : OpenSaaS Sp. z o.o. 
 *  Licence			: GPL
 *  Help/Email      : bok@opensaas.pl                                                                                                                 
 *  Website         : www.vtiger.com.pl, www.opensaas.pl
 ********************************************************************************+*/
$mod_strings = array(
	'LBL_CREATE_ZIP_FAILURE' => 'Błąd przy tworzeniu pliku ZIP',
	'LBL_ZIP_FILE_ADD_FAILURE' => 'Błąd przy dodaniu pliku ZIP',
	'LBL_FTP_CONNECT_FAILED' => 'Błąd połączenia do serwera FTP',
	'LBL_FTP_LOGIN_FAILED' => 'Błąd logowania do serwera FTP',
);

?>