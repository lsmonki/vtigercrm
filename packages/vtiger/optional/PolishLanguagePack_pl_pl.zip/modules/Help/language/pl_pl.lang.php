<?php
 /*+********************************************************************************
 * Terms & Conditions are placed on the: http://vtiger.com.pl
 ********************************************************************************
 *  Language		: Język Polski
 *  Vtiger Version	: 5.4.x
 *	Pack Version	: 1.13
 *  Author          : OpenSaaS Sp. z o.o. 
 *  Licence			: GPL
 *  Help/Email      : bok@opensaas.pl                                                                                                                 
 *  Website         : www.vtiger.com.pl, www.opensaas.pl
 ********************************************************************************+*/
$mod_strings = Array(
'LBL_MODULE_NAME'=>'Kontrahenci',
'LBL_MODULE_TITLE'=>'Kontrahenci: Strona główna',
'LBL_SEARCH_FORM_TITLE'=>'Szukaj Kontrahenta',
'LBL_LIST_FORM_TITLE'=>'Lista Kontrahentów',
'LBL_NEW_FORM_TITLE'=>'Nowy Kontrahent',
'ERR_DELETE_RECORD'=>'Musisz wpierw zaznaczyć wpis, aby możliwe było usunięcie.',
);
?>