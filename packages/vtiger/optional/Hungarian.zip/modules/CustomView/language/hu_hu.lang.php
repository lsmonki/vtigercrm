<?php 
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version 1.1.2
 * ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an  "AS IS"  basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License for
 * the specific language governing rights and limitations under the License.
 * The Original Code is:  SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************
 * $Header:  \modules\CustomView\language\hu_hu.lang.php - 12:04 2011.11.11. $
 * Description:  Defines the Hungarian language pack for the CustomView module vtiger 5.3.x
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): Istvan Holbok,  e-mail: holbok@gmail.com , mobil: +3670-3420900 , Skype: holboki
 ********************************************************************************/
$mod_strings = Array( 
'LBL_MODULE_NAME'=>'Egyedi nézet', 
'LBL_STEP_1_TITLE'=>'Nézet Információ', 
'LBL_VIEW_NAME'=>'Nézet neve:', 
'LBL_SETDEFAULT'=>'Alapértelmezettként beállít', 
'LBL_LIST_IN_METRICS'=>'Mérőszámok listája', 
'LBL_STEP_2_TITLE'=>'Válassz oszlopokat', 
'LBL_STEP_3_TITLE'=>'Standard Szűrők', 
'LBL_STEP_4_TITLE'=>'Haladó Szűrők', 
'LBL_STEP_5_TITLE'=>'Hozzáférés Információ', 
'LBL_SF_COLUMNS'=>'Oszlop', 
'LBL_SF_STARTDATE'=>'Kezdés Dátuma', 
'LBL_SF_ENDDATE'=>'Befejezés dátuma', 
'LBL_AF_HDR1'=>'Add meg a keresési feltételeket a lista további szűkítéséhez.', 
'LBL_AF_HDR2'=>'Használhatod az &quot;or&quot; (vagy) operátort, ha több értéket is akarsz a harmadik oszlopba írni.', 
'LBL_AF_HDR3'=>'Legfeljebb 10 tételt vesszővel elválasztva is megadhatsz. Például: CA, NY, TX, FL megadása esetén keresni fog CA vagy NY vagy TX vagy FL értékekre', 
'LBL_AF_HDR4'=>'Ha a "Tevékenység Típus"-t választod, akkor a következők valamelyik add meg "Call","Meeting" vagy "Task".', 
 
//strings added for vtiger 5, date format... 
'LBL_NONE'=>'Nincs', 
'View_Name'=>'Nézet neve', 
'LBL_AND'=>'és', 
'LBL_DATE_FORMAT_CUSTOMVIEW'=>'É-h-n', 
//Strings added for filter 
'Custom'=>'Egyedi',
'Previous FY'=>'Előző pü.Év',
'Current FY'=>'Aktuális pü.Év',
'Next FY'=>'Következő pü.Év',
'Previous FQ'=>'Előző pü.nÉv',
'Current FQ'=>'Aktuális pü.nÉv',
'Next FQ'=>'Következő pü.nÉv',
'Yesterday'=>'Tegnap', 
'Today'=>'Ma', 
'Tomorrow'=>'Holnap', 
'Last Week'=>'Elmúlt hét', 
'Current Week'=>'Aktuális hét', 
'Next Week'=>'Következő hét', 
'Last Month'=>'Elmúlt hónap', 
'Current Month'=>'Aktuális hónap', 
'Next Month'=>'Következő hónap', 
'Last 7 Days'=>'Elmúlt 7 nap', 
'Last 30 Days'=>'Elmúlt 30 nap', 
'Last 60 Days'=>'Elmúlt 60 nap', 
'Last 90 Days'=>'Elmúlt 90 nap', 
'Last 120 Days'=>'Elmúlt 120 nap', 
'Next 30 Days'=>'Következő 30 nap', 
'Next 60 Days'=>'Következő 60 nap', 
'Next 90 Days'=>'Következő 90 nap', 
'Next 120 Days'=>'Következő 120 nap', 
 
'None'=>'üres',
'equals'=>'egyenlő ezzel', 
'contains'=>'tartalmazza ezt', 
'does not contain'=>'nem tartalmazza ezt', 
'less than'=>'kisebb, mint ez', 
'greater than'=>'nagyobb, mint ez', 
'less or equal'=>'kisebb vagy egyenlő, mint ez', 
'greater or equal'=>'nagyobb vagy egyenlő, mint ez', 
 
//Strings added to translate field label vtiger_groups 
'Address'=>'Cím', 
'Information'=>'Információ', 
'Description'=>'Megjegyzés', 
'Custom Information'=>'Egyedi Információ', 
'- Event Information'=>'- Esemény Információ', 
'- Event Description'=>'- Esemény Leírás', 
'- Task Information'=>'- Feladat Információ', 
'- Task Description'=>'- Feladat Leírás', 
 
//Strings added for helpdesk module fields 
'Title'=>'Megnevezés', 
'Assigned To'=>'Felelős', 
'Related to'=>'Kapcsolódik', 
'Priority'=>'Prioritás', 
'Product Name'=>'Termék neve', 
'Severity'=>'Komolyság', 
'Status'=>'Állapot', 
'Category'=>'Kategória', 
'Created Time'=>'Létrehozva', 
'Modified Time'=>'Módosítva', 
'Attachment'=>'Melléklet', 
 
//Strings added for Leads module fields 
'First Name'=>'Keresztnév', 
'Phone'=>'Telefon', 
'Last Name'=>'Vezetéknév', 
'Company'=>'Cég', 
'Lead Source'=>'Jelölt Forrás', 
'Website'=>'Weboldal', 
'Industry'=>'Iparág', 
'Lead Status'=>'Jelölt Állapot', 
'Annual Revenue'=>'Éves jövedelem', 
'Rating'=>'Értékelés', 
'No Of Employees'=>'Alkalmazottak száma', 
'Street'=>'Utca', 
'Po Box'=>'Postafiók', 
'Postal Code'=>'Irányítószám', 
'City'=>'Város', 
'Country'=>'Ország', 
'State'=>'Állam/megye', 
 
//Strings added for Accounts module fields 
'Account Name'=>'Cég neve', 
'Ticker Symbol'=>'Tőzsdei rövidítés', 
'Other Phone'=>'Telefon, másik', 
'Member Of'=>'Tagja', 
'Employees'=>'Alkalmazottak', 
'Other Email'=>'Email cím, másik', 
'Ownership'=>'Tulajdonos', 
'industry'=>'Iparág', 
'SIC Code'=>'TEÁOR',
'Email Opt Out'=>'Email leiratkozott', 
'Billing Address'=>'Számlázási cím - Utca', 
'Shipping Address'=>'Szállítási cím - Utca', 
'Shipping Po Box'=>'Szállítási cím - Postafiók', 
'Billing Po Box'=>'Számlázási cím - Postafiók', 
'Billing City'=>'Számlázási cím - Város', 
'Shipping City'=>'Szállítási cím - Város', 
'Billing State'=>'Számlázási cím - Állam/megye', 
'Shipping State'=>'Szállítási cím - Állam/megye', 
'Billing Code'=>'Számlázási cím - Irányítószám', 
'Shipping Code'=>'Szállítási cím - Irányítószám', 
'Shipping Country'=>'Szállítási cím - Ország', 
'Billing Country'=>'Számlázási cím - Ország', 
 
 
//Strings added for Contacts module fields 
 
'Office Phone'=>'Telefon, irodai', 
'Home Phone'=>'Telefon, otthoni', 
'Birthdate'=>'Születésnap', 
'Reports To'=>'Jelent neki', 
'Assistant Phone'=>'Telefon, asszisztens', 
'Do Not Call'=>'Ne hívd', 
'Mailing Street'=>'Utca (Levelezés)', 
'Other Street'=>'Utca (másik)', 
'Mailing Po Box'=>'Postafiók (Levelezés)', 
'Other Po Box'=>'Postafiók (másik)', 
'Mailing City'=>'Város (Levelezés)', 
'Other City'=>'Város (másik)', 
'Mailing State'=>'Állam/megye (Levelezés)', 
'Other State'=>'Állam/megye (másik)', 
'Mailing Zip'=>'Írányítószám (Levelezés)', 
'Other Zip'=>'Írányítószám (másik)', 
'Mailing Country'=>'Ország (Levelezés)', 
'Other Country'=>'Ország (másik)', 
 
 
//Strings added for Potential module fields 
 
'Potential Name'=>'Lehetőség neve', 
'Amount'=>'Összeg', 
'Expected Close Date'=>'Várható lezárási dátum', 
'Next Step'=>'Következő lépés', 
'Sales Stage'=>'Értékesítési fázis', 
'Probability'=>'Valószínűség', 
 
 
//Strings added for Quotes module fields 
'Subject'=>'Tárgy', 
'Quote Stage'=>'Ajánlati fázis', 
'Valid Till'=>'Érvényes eddig: ', 
'Team'=>'Csapat', 
'Contact Name'=>'Kapcsolat neve', 
'Carrier'=>'Futár', 
'Shipping'=>'Szállítás', 
'Inventory Manager'=>'Termelési menedzser', 
 
//Strings added for Sales Orders module fields 
'Customer No'=>'Vevő száma', 
'Quote Name'=>'Ajánlat neve', 
'Purchase Order'=>'Beszerzések', 
'Due Date'=>'Határidő', 
'Pending'=>'Függőben', 
'Sales Commission'=>'Értékesítési jutalék', 
'Excise Duty'=>'Jövedéki adó', 
 
//Strings added for Invoices module fields 
'Sales Order'=>'Megrendelés', 
'Invoice Date'=>'Díjbekérő dátuma', 
 
//Strings added for Product module fields 
'Product Active'=>'Aktív Termék', 
'Product Category'=>'Termék kategória', 
'Sales Start Date'=>'Értékesítés kezdő dátuma', 
'Sales End Date'=>'Értékesítés befejező dátuma', 
'Support Start Date'=>'Támogatás kezdő dátuma', 
'Support Expiry Date'=>'Támogatás befejező dátuma', 
'Vendor Name'=>'Beszállító neve', 
'Mfr PartNo'=>'Mfr PartNo', 
'Vendor PartNo'=>'Beszállító PartNo', 
 
'Serial No'=>'Sorozat szám', 
'Product Sheet'=>'Termék adatlap', 
'GL Account'=>'Főkönyvi szám', 
 
//Strings added for Price book module fields 
'Price Book Name'=>'Csomagár megnevezése', 
'Active'=>'Aktív', 
 
//Strings added for tasks & events module fields 
'Start Date & Time'=>'Kezdés Dátuma és Ideje', 
 
//error message 
'Missing required fields'=>'Hiányzó kötelező vtiger_fields (VTiger mezők)', 
//Strings added for campaigns 
'Campaign Name'=>'Kampány neve', 
'Campaign Type'=>'Kampány típusa', 
'Product'=>'Termék', 
'Campaign Status'=>'Kampány állapot', 
'Expected Revenue'=>'Várható jövedelem', 
'Budget Cost'=>'Tervezett költség', 
'Actual Cost'=>'Jelenlegi költség', 
'Expected Response'=>'Várható reakció', 
'Num Sent'=>'Küldött db', 
'Target Audience'=>'Célközönség', 
'TargetSize'=>'Cél méret', 
'Sponsor'=>'Szponzor', 
'Expected Sales Count'=>'Várható megrendelések száma', 
'Expected Response Count'=>'Várható visszajelzési darabszám', 
'Expected ROI'=>'Várható megtérülés', 
'Actual Sales Count'=>'Jelenleg: megrendelések száma', 
'Actual Response Count'=>'Jelenlegi visszajelzési darabszám', 
'Actual ROI'=>'Jelenlegi megtérülés', 
 
 
 
//Added for customview.tpl 
 
'LBL_Select_a_Column'=>'Válassz egy Oszlopot', 
'Missing_required_fields'=>'Hiányzó kötelező mezők', 
'Details'=>'Részletes adatok', 
'New_Custom_View'=>'Új Egyedi Nézet',
'Edit_Custom_View'=>'Egyedi Nézet Szerkesztése', 
'LBL_AF_HDR5'=>'Az Egyszerű idő szűrő lehetővé teszi neked, hogy dátumokat válassz a <b>Cég - Létrehozva: Idő</b> vagy a <b>Cég - Módosítva: Idő</b> alapján.', 
'Select_Duration'=>'Válassz időtartamot', 
'Simple_Time_Filter'=>'Egyszerű idő szűrő', 
'Start_Date'=>'Kezdés Dátuma', 
'End_Date'=>'Befejezés dátuma', 
'LBL_RULE'=>'Szabály',

// Added/Updated for vtiger CRM 5.0.4
'not equal to'=>'nem egyenlő ezzel',
'starts with'=>'kezdődik ezzel',
'ends with'=>'végződik ezzel',
//'Product Code'=>'Product Code',

// Added after 5.0.4 GA

//Added for Role based Custom filters 
'LBL_SET_AS_PUBLIC'=>'Beállít, mint Nyilvános ',
'LBL_NEW'=>'Új',
'LBL_EDIT'=>'Szerkeszt',
'LBL_STATUS_PUBLIC_APPROVE'=>'Elfogad',
'LBL_STATUS_PUBLIC_DENY'=>'Visszautasít',
'LBL_ADVANCED_FILTER' => 'Munkakör',
'yyyy-mm-dd'=>'éééé-hh-nn'
); 
?>
