<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'PortalClienti',
'LBL_BASIC_SETTINGS'=>'Setari de baza',
'LBL_ADVANCED_SETTINGS'=>'Setari avansate',
'LBL_MODULE'=>'Modul',
'LBL_VIEW_ALL_RECORD'=>'Vizualizeaza toate inregistrarile aferente?',
'YES'=>'Da',
'NO'=>'Nu',
'LBL_USER_DESCRIPTION'=>'Profilul Utilizatorului/ilor selectat/i mai sus va/vor fi ales/e pentru a controla campurile ce apar in Portal Clienti
				Puteti activa/dezactiva campurile afisate in Portal Clienti.',
'SELECT_USERS'=>'Selecteaza Utilizatori',				
'LBL_DISABLE'=>'Dezactiveaza',
'LBL_ENABLE' =>'Activeaza',
'Module' => 'Modul',
'Sequence' =>'Succesiune',
'Visible'=>'Vizibil'

);

?>
