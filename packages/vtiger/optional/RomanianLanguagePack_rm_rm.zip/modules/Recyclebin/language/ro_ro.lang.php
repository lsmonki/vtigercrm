<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$mod_strings = Array(
'RecycleBin' => 'Cos de gunoi',
'MSG_EMPTY_RB_CONFIRMATION'=>'Sunteti sigur ca doriti sa stergeti definitiv toate inregistrarile sterse din baza de date?',
'LBL_SELECT_MODULE'=>'Selecteaza Modul',
'LBL_EMPTY_MODULE'=>'Zero inregistrari gasite pentru a fi restaurate in modul',
'LBL_MASS_RESTORE'=>'Restaureaza',
'LBL_EMPTY_RECYCLEBIN'=>'Goleste Cos de gunoi',
'LNK_RESTORE'=>'restaureaza',
'LBL_NO_PERMITTED_MODULES'=>'Zero module permise disponibile',
);

?>