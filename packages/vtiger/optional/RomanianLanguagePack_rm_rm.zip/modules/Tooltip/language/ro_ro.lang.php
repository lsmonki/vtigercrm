<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
* 
 ********************************************************************************/

$mod_strings = Array (
'Tooltip' => 'ToolTip',
'LBL_TOOLTIP_MANAGEMENT'=>'Management Tooltip',
'LBL_TOOLTIP_MANAGEMENT_DESCRIPTION'=>'Gestioneaza informatie tooltip de aici',
'LBL_FIELDS_IN'=>'Campuri in',
'LBL_TOOLTIP_HELP_TEXT'=>'Selectati campurile care doriti sa fie afisate tooltip',
'LBL_FIELD'=>'Camp',

);

?>
