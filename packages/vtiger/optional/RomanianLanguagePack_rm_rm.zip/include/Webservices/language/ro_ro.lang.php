<?php
/***********************************************************
*  Module       : Webservices
*  Language     : Romana
*  Version      : 5.1.0 RC
*  Created Date : 2009-08-28 21:36:13 
*  Last change  : 2009-07-21 00:49:17
*  Author       : Magister Software
*  License      : GPL

***********************************************************/
$app_strings = array (
	'Groups'=>'Grupuri',
	'DocumentFolders'=>'Directoare Documente',
	'Currency'=>'Moneda',
	'SINGLE_Groups'=>'Grup',
	'SINGLE_DocumentFolders'=>'Director Document',
	'SINGLE_Currency'=>'Moneda',
);
?>