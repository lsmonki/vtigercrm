<?php
$mod_strings = array (
  'LBL_SYSTEM_CONFIG' => 'Configurazioni di Sistema',

);
?>