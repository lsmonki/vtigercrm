<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'Portale Clienti',
'LBL_BASIC_SETTINGS'=>'Impostazioni Base',
'LBL_ADVANCED_SETTINGS'=>'Impostazioni Avanzate',
'LBL_MODULE'=>'Modulo',
'LBL_VIEW_ALL_RECORD'=>'Vede Tutti i Record Relazionati ?',
'YES'=>'Sì',
'NO'=>'No',
'LBL_USER_DESCRIPTION'=>'Il Profilo Utente selezionato qui sopra controlla i campi che sono visibili nel Portale Clienti. Puoi abilitare e disabilitare in questo modo i campi mostrati sul Portale.',
'SELECT_USERS'=>'Seleziona l\'Utente',				
'LBL_DISABLE'=>'Disabilita',
'LBL_ENABLE' =>'Abilita',
'Module' => 'Modulo',
'Sequence' =>'Sequenza',
'Visible'=>'Visibile'

);

?>
