<?php
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Amministrazione',
  'LBL_MODULE_TITLE' => 'Amministrazione: Home',
  'LBL_NEW_FORM_TITLE' => 'Nuova Azienda',
  'ERR_DELETE_RECORD' => 'Selezionare almeno un\'entit&agrave;  per poter cancellare l\'azienda.',

);
?>