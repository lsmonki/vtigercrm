<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/

$mod_strings = Array(
'RecycleBin' => 'Cestino',
'Recycle Bin' => 'Cestino',
'LBL_MODULE_NAME'=>'Cestino',
'MSG_EMPTY_RB_CONFIRMATION'=>'Sei sicuro di voler cancellare definitivamente tutti i record  dal tuo database?',
'LBL_SELECT_MODULE'=>'Seleziona Modulo',
'LBL_EMPTY_MODULE'=>'Non ci sono record da ripristinare nel modulo',
'LBL_MASS_RESTORE'=>'Ripristina',
'LBL_EMPTY_RECYCLEBIN'=>'Svuota il cestino',
'LNK_RESTORE'=>'Ripristina',
'LBL_NO_PERMITTED_MODULES'=>'Non hai permessi sufficienti sul modulo',
);

?>
