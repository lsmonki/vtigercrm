<?php
$mod_strings = array (
  'LBL_ATTACH_FILE' => 'Allega File',
  'LBL_ATTACH' => 'Allega',
  'LBL_CANCEL' => 'Annulla',
  'LBL_STEP_SELECT_FILE' => 'Step 1 : Seleziona File',
  'LBL_BROWSE_FILES' => 'Clicca il pulsante &#39;browse&#39; e seleziona il file da allegare',
  'LBL_DESCRIPTION' => 'Step 2 : Scrivi una descrizione',
  'LBL_OPTIONAL' => '(opzionale)',

);
?>