<?php
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Aziende',
  'LBL_MODULE_TITLE' => 'Aziende: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Aziende',
  'LBL_LIST_FORM_TITLE' => 'Lista Aziende',
  'LBL_NEW_FORM_TITLE' => 'Nuova Azienda',
  'ERR_DELETE_RECORD' => 'Deve essere selezionato almeno un record per poter cancellare l\'azienda',

);
?>