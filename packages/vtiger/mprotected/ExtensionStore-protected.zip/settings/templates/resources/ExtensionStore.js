/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
jQuery.Class('Settings_Module_Import_Js', {
    
},{
    /**
	 * Function to get import module step1 params
	 */
	getImportModuleStep1Params : function(){
            var params = {
                        'module' : app.getModuleName(),
                        'parent' : app.getParentModuleName(),
                        'view' : 'ExtensionImport',
                        'mode' : 'step1'
                    };
            return params;
	},
    
	/**
	 * Function to get import module with respect to view
	 */
	getImportModuleStepView : function(params){
            var aDeferred = jQuery.Deferred();
            var progressIndicatorElement = jQuery.progressIndicator({
                    'position' : 'html',
                    'blockInfo' : {
                            'enabled' : true
                    }
            });

            AppConnector.request(params).then(
                    function(data) {
                            progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                            aDeferred.resolve(data);
                    },
                    function(error) {
                            progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                            aDeferred.reject(error);
                    }
            );
            return aDeferred.promise();
	},
        
        /**
         * Function to register raty
         */
        registerRaty : function() {
            jQuery('.rating').raty({
                score: function() {
                  return this.getAttribute('data-score');
                },
                readOnly: function() {
                  return this.getAttribute('data-readonly');
                }
            });
        },
    
        /**
	 * Function to register event for step1 of import module
	 */
	registerEventForStep1 : function(){
                this.registerRaty();
		var detailContentsHolder = jQuery('.contentsDiv');
		app.showScrollBar(jQuery('.extensionDescription'), {'height':'120px','width':'100%','railVisible': true});
		this.registerEventsForImportModuleStep1(detailContentsHolder);
	},
    
    /**
	 * Function to register event related to Import extrension Modules in step1
	 */
	registerEventsForImportModuleStep1 : function(container){
		var thisInstance = this;
		jQuery(container).find('.installExtension').on('click',function(e){
                        thisInstance.installExtension(e);
		});
                
                jQuery(container).find('.installPaidExtension').on('click',function(e){
                    var customerCardId = jQuery(container).find('[name="customerCardId"]').val();
                    if(customerCardId.length == 0){
                        var cardSetupError = app.vtranslate('JS_PLEASE_SETUP_CARD_DETAILS_TO_INSTALL_THIS_EXTENSION');
                        var params = {
                                text: cardSetupError
                        };
                        Settings_Vtiger_Index_Js.showMessage(params);
                    }else {
                        thisInstance.installExtension(e);
                    }
                });
                
                jQuery(container).on('keydown','#searchExtension',function(e){
                    var currentTarget = jQuery(e.currentTarget);
                    var code = e.keyCode;
                    if(code == 13){
                        var searchTerm = currentTarget.val();
                        var params = {
                            'module' : app.getModuleName(),
                            'parent' : app.getParentModuleName(),
                            'view' : 'ExtensionImport',
                            'mode' : 'searchExtension',
                            'searchTerm' : searchTerm
                        };
                        
                        var progressIndicatorElement = jQuery.progressIndicator({
                                'position' : 'html',
                                'blockInfo' : {
                                        'enabled' : true
                                }
                        });
                        AppConnector.request(params).then(
                            function(data) {
                                    jQuery('#extensionContainer').html(data);
                                    thisInstance.registerRaty();
                                    thisInstance.registerEventForStep1();
                                    progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                            },
                            function(error) {
                                    progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                            }
                        );
                    }
                })
                jQuery(container).on('click','#registerUser',function(e){
                    var params = {
                            'module' : app.getModuleName(),
                            'parent' : app.getParentModuleName(),
                            'action' : 'Basic',
                            'mode' : 'createProfile'
                        };
                     var progressIndicatorElement = jQuery.progressIndicator({
                            'position' : 'html',
                            'blockInfo' : {
                                    'enabled' : true
                            }
                    });
                    AppConnector.request(params).then(
                        function(data) {
                                progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                        },
                        function(error) {
                                progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                        }
                    );
                });
                jQuery(container).on('click','#setUpCardDetails',function(e){
                    var element = jQuery(e.currentTarget);
                    var setUpCardModal = jQuery(container).find('.setUpCardModal').clone(true, true);
                    setUpCardModal.removeClass('hide');
                    
                    var callBackFunction = function(data) {
                        jQuery(data).on('click','[name="resetButton"]',function(e){
                            jQuery(data).find('[name="cardNumber"],[name="expMonth"],[name="expYear"], [name="cvccode"]').val('');
                        })
                        var form = data.find('.setUpCardForm');
                        var params = app.getvalidationEngineOptions(true);
                        params.onValidationComplete = function(form, valid){
                                if(valid) {
                                    var formData = form.serializeFormData();
                                    var progressIndicatorElement = jQuery.progressIndicator();
                                    AppConnector.request(formData).then(
                                            function(data){
                                                    if(data['success']) {
                                                        jQuery(container).find('[name="customerCardId"]').val(data.result.id);
                                                        progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                                                        element.html(app.vtranslate('JS_UPDATE_CARD_DETAILS'));
                                                        app.hideModalWindow();
                                                    }
                                            }
                                    );
                                }
                                return false;
                        };
                        form.validationEngine(params);
                    };
                    
                    app.showModalWindow(setUpCardModal,function(data) {
				if(typeof callBackFunction == 'function') {
					callBackFunction(data);
				}
			}, {'width':'1000px'});
                });
	},
        
        installExtension : function(e){
            var thisInstance = this;
            var element = jQuery(e.currentTarget);
            var extensionContainer = element.closest('.extension_container');
            var extensionId = extensionContainer.find('[name="extensionId"]').val();
            var moduleAction = extensionContainer.find('[name="moduleAction"]').val(); 
            var extensionName = extensionContainer.find('[name="extensionName"]').val();
            
            if(element.hasClass('protectedExtension')){
                //Check for extension loader to download extension
                var checkParams = {
                    'module' : app.getModuleName(),
                    'parent' : app.getParentModuleName(),
                    'action' : 'Basic',
                    'mode'   : 'ExtensionImport'
                }

                AppConnector.request(checkParams).then(
                    function(data){
                        var success = data.result.success;
                        if(!success){
                            var errorMessage = app.vtranslate('JS_PLEASE_INSTALL_EXTENSION_LOADER_TO_INSTALL_THIS_EXTENSION_FROM_BELOW_LINK');
                            var params = {
                                    text: errorMessage
                            };
                            Settings_Vtiger_Index_Js.showMessage(params);
                            return false;
                        } else {
                            thisInstance.DownloadExtension(element);
                        }
                });
            } else {
                thisInstance.DownloadExtension(element);
            }
        },
        
        /**
         * Function to download Extension
         */
        DownloadExtension : function(element){
            var thisInstance = this;
            var extensionContainer = element.closest('.extension_container');
            var extensionId = extensionContainer.find('[name="extensionId"]').val();
            var moduleAction = extensionContainer.find('[name="moduleAction"]').val(); 
            var extensionName = extensionContainer.find('[name="extensionName"]').val();
            var params = {
                    'module' : app.getModuleName(),
                    'parent' : app.getParentModuleName(),
                    'view' : 'ExtensionImport',
                    'mode' : 'step2',
                    'extensionId' : extensionId,
                    'moduleAction' : moduleAction,
                    'extensionName' : extensionName
            };

            this.getImportModuleStepView(params).then(function(data){
                    var detailContentsHolder = jQuery('.contentsDiv');
                    detailContentsHolder.html(data);
                    thisInstance.registerEventsForImportModuleStep2(detailContentsHolder);
            });
        },
    
    /**
	 * Function to register event related to Import extrension Modules in step2
	 */
	registerEventsForImportModuleStep2 : function(container){
		var container = jQuery(container);
                app.showScrollBar(jQuery('div.scrollableTab'), {'width': '100%', 'height':'400px'});
		var thisInstance = this;
		this.registerRaty();
                slider =  jQuery('#imageSlider').bxSlider({
                        auto: true,
                        pause: 1000,
                        randomStart : true,
                        autoHover: true
                });
                jQuery("#screenShots").on('click',function() { 
                    slider.reloadSlider();
                });

            container.find('#installExtension').on('click',function(){
                var extensionId = jQuery('[name="extensionId"]').val();
                var targetModule = jQuery('[name="targetModule"]').val();
                var moduleType = jQuery('[name="moduleType"]').val();
                var moduleAction = jQuery('[name="moduleAction"]').val();
                var fileName = jQuery('[name="fileName"]').val();

                var params = {
                        'module' : app.getModuleName(),
                        'parent' : app.getParentModuleName(),
                        'view' : 'ExtensionImport',
                        'mode' : 'step3',
                        'extensionId' : extensionId,
                        'moduleAction' : moduleAction,
                        'targetModule' : targetModule,
                        'moduleType' : moduleType,
                        'fileName' : fileName
                }

                thisInstance.getImportModuleStepView(params).then(function(step3Data){
                        var callBackFunction = function(data){
                                var installationStatus = jQuery(data).find('[name="installationStatus"]').val();
                                if(installationStatus == "success"){
                                        jQuery('#installExtension').remove();
                                        jQuery('#launchExtension').removeClass('hide');
                                }
                                app.showScrollBar(jQuery('#installationLog'), {'height':'150px'});
                        };
                        var modalData = {
                                data : step3Data,
                                css : {'width':'60%','height':'auto'},
                                cb : callBackFunction
                        };
                        app.showModalWindow(modalData);
                });
            });
            
            container.find('#uninstallModule').on('click',function(){
                var extensionName = container.find('[name="targetModule"]').val();
                var params = {
                                'module' : app.getModuleName(),
                                'parent' : app.getParentModuleName(),
                                'action' : 'Basic',
                                'mode'   : 'uninstallExtension',
                                'extensionName' : extensionName
                            };
               
               var progressIndicatorElement = jQuery.progressIndicator();
                AppConnector.request(params).then(
                        function(data){
                               progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                               container.find('#declineExtension').trigger('click');
                        });
                
            });
		
            container.find('#declineExtension').on('click',function(){
                    var params = thisInstance.getImportModuleStep1Params();
                    thisInstance.getImportModuleStepView(params).then(function(data){
                    var detailContentsHolder = jQuery('.contentsDiv');
                    detailContentsHolder.html(data);
                            thisInstance.registerEventForStep1();
                    });
            });
                
            container.on('click','.writeReview',function(e){
                var customerReviewModal = jQuery(container).find('.customerReviewModal').clone(true, true);
                customerReviewModal.removeClass('hide');

                var callBackFunction = function(data) {
                    var form = data.find('.customerReviewForm');
                   form.find('.rating').raty();
                    var params = app.getvalidationEngineOptions(true);
                    params.onValidationComplete = function(form, valid){
                            if(valid) {
                                var review = form.find('[name="customerReview"]').val();
                                var listingId = form.find('[name="extensionId"]').val();
                                var rating = form.find('[name="score"]').val();
                                var params = {
                                    'module' : app.getModuleName(),
                                    'parent' : app.getParentModuleName(),
                                    'action' : 'Basic',
                                    'mode' : 'postReview',
                                    'comment' : review,
                                    'listing' :  listingId,
                                    'rating'    : rating
                                }
                                var progressIndicatorElement = jQuery.progressIndicator();
                                AppConnector.request(params).then(
                                        function(data){
                                                if(data['success']) {
                                                    var result = data['result']
                                                    if(result){
                                                        var dateParams = {
                                                            'module' : app.getModuleName(),
                                                            'parent' : app.getParentModuleName(),
                                                            'action' : 'Basic',
                                                            'mode' : 'getDateString',
                                                            'date' : result.createdon
                                                        }
                                                        AppConnector.request(dateParams).then(
                                                            function(data){
                                                              var dateString = data.result;
                                                                var html =  '<div class="row-fluid">'+
                                                                                '<span class="span3" style="padding-bottom: 10px">'+
                                                                               result.CustomerId+' '+ app.vtranslate("JS_ON")+' '+ dateString +
                                                                               '</span>'+
                                                                               '<span class="span6 rating appendRating margin0px" data-score="'+result.rating+'"></span><span class="span1 margin0px">('+result.rating+' '+app.vtranslate("JS_RATINGS")+')</span>'+
                                                                               '</div>'+
                                                                               '<div class="row-fluid"><span class="span9">'+result.comment+'</span></div><hr>';
                                                               container.find('.customerReviewContainer').append(html);
                                                               container.find('.appendRating').raty({
                                                                score: function() {
                                                                  return this.getAttribute('data-score');
                                                                    }
                                                                });
                                                        });
                                                    }
                                                    progressIndicatorElement.progressIndicator({'mode' : 'hide'});
                                                    app.hideModalWindow();
                                                }
                                        }
                                );
                            }
                            return false;
                    }
                    form.validationEngine(params);
                }

                app.showModalWindow(customerReviewModal,function(data) {
                            if(typeof callBackFunction == 'function') {
                                    callBackFunction(data);
                            }
                    }, {'width':'1000px'});
            });
	},
    
    registerEvents : function() {
        this.registerEventForStep1();
    }
});



jQuery(document).ready(function(){
	var settingModuleImportInstance = new Settings_Module_Import_Js();
	settingModuleImportInstance.registerEvents();
})



