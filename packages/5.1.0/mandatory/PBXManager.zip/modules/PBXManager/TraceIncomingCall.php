<?php
/**
 * Created on 04-Sep-08
 * this file checks if any incoming call is there for the current user or not if asterisk is configured
 */
echo TraceIncomingCall();

/**
 * This function traces an incoming call and adds it to the databse for vtiger to pickup,
 * it also adds an entry to the activity history of the related Contact/Lead/Account
 * only these three modules are supported for now
 */
function TraceIncomingCall(){
	require_once 'include/utils/utils.php';
	require_once('modules/PBXManager/AsteriskUtils.php');
	global $adb, $current_user;
	global $theme,$app_strings;

	$theme_path="themes/".$theme."/";
	$image_path=$theme_path."images/";
	
	$sql = "select * from vtiger_asteriskextensions where userid = ".$current_user->id;
	$result = $adb->query($sql);
	$asterisk_extension = $adb->query_result($result, 0, "asterisk_extension");
	
	$query = "select * from vtiger_asteriskincomingcalls where to_number = ?";
	$result = $adb->pquery($query, array($asterisk_extension));
	
	if($adb->num_rows($result)>0){
		$flag = $adb->query_result($result,0,"flag");
		$oldTime = $adb->query_result($result,0,"timer");
		$callerNumber = $adb->query_result($result,0,"from_number");
		$callerName = $adb->query_result($result,0,"from_name");
		$callerType = $adb->query_result($result,0,"callertype");
		
		if(!empty($callerType)){
			$caller = getCallerName("$callerType:".$callerNumber);
		}else{
			$caller = getCallerName($callerNumber);
		}
		$newTime = time();
		if(($newTime-$oldTime)>=3 && $flag == 1){ 
			$adb->pquery("delete from vtiger_asteriskincomingcalls where to_number = ?", array($asterisk_extension));
		}else{
			if($flag==0){
				asterisk_addToActivityHistory($callerName, $callerNumber, $callerType, $adb, $current_user);
				$flag=1;
				$adb->pquery("update vtiger_asteriskincomingcalls set flag = ? where to_number = ?", array($flag, $asterisk_extension));
			}
			//prepare the div for incoming calls
			$status = "	<table  border='0' cellpadding='5' cellspacing='0'>
						<tr>
							<td style='padding:10px;' colspan='2'><b>".$app_strings['LBL_INCOMING_CALL']."</b></td>
						</tr>
					</table>
					<table  border='0' cellpadding='0' cellspacing='0' class='hdrNameBg'>
						<tr><td style='padding:10px;' colspan='2'><b>".$app_strings['LBL_CALLER_INFORMATION']."</b>
							<br><b>".$app_strings['LBL_CALLER_NUMBER']."</b> $callerNumber
							<br><b>".$app_strings['LBL_CALLER_NAME']."</b> $callerName
						</td></tr>
						<tr><td style='padding:10px;' colspan='2'><b>".$app_strings['LBL_INFORMATION_VTIGER']."</b>
							<br> $caller
						</td></tr>
					</table>";
		}
	}else{
		$status = "failure";
	}
	return $status;
}


?>
