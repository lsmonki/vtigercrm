<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'FieldFormulas' => 'Field Formulas',
'LBL_FIELDFORMULAS'=>'Field Formulas',
'LBL_FIELDFORMULAS_DESCRIPTION'=>'Add custom equations to custom fields', 
'LBL_FUNCTIONS'=>'Functions',
'LBL_LIST_FIELD'=>'Field',
'LBL_LIST_EXPRESSION'=>'Expression',
'LBL_LIST_SETTINGS' => 'Settings'
);

?>
