<?php
/*********************************************************************************
** The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
* 
 ********************************************************************************/

$mod_strings = Array (
'Tooltip' => 'ToolTip',
'LBL_TOOLTIP_MANAGEMENT'=>'Tooltip Management',
'LBL_TOOLTIP_MANAGEMENT_DESCRIPTION'=>'Manage the tooltip information from here',
'LBL_FIELDS_IN'=>'Fields in',
'LBL_TOOLTIP_HELP_TEXT'=>'Select the fields that you would like to be displayed as tooltip',
'LBL_FIELD'=>'Field',

);

?>
