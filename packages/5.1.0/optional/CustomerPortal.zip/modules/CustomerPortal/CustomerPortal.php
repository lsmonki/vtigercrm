<?php
/** YOUR LICENSE TEXT HERE **/
?>
