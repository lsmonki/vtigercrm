<?php

$defaultUserName = 'admin';
$defaultUserAccessKey = 'HQdvokz3701TPtfn';

$defaultOwner = 'standarduser';
$successURL = '';
$failureURL = '';

/**
 * JSON or HTML. if incase success and failure URL is NOT specified.
 */
$defaultSuccessAction = 'HTML';

$defaultSuccessMessage = 'LBL_SUCCESS';

?>
