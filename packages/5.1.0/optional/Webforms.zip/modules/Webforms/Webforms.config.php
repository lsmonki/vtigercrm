<?php

$enableAppKeyValidation = true;
$defaultUserName = 'admin';
$defaultUserAccessKey = 'iFOdqrI8lS5UhNTa';

$defaultOwner = 'standarduser';
$successURL = '';
$failureURL = '';

/**
 * JSON or HTML. if incase success and failure URL is NOT specified.
 */
$defaultSuccessAction = 'HTML';

$defaultSuccessMessage = 'LBL_SUCCESS';

?>
