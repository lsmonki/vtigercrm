/** YOUR LICENSE TEXT HERE **/
var custom_alert_arr = {
			NEED_TO_ADD_A :'You need to add a', 
			CUSTOM_FIELD :'Custom field'
}
