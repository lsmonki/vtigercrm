<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'FieldFormulas' => 'Field Formulas',
'LBL_FIELDFORMULAS' => 'Field Formulas',
'LBL_FIELDFORMULAS_DESCRIPTION' => 'Add custom equations to custom fields',
'LBL_FIELDS' => 'Fields',
'LBL_FUNCTIONS' => 'Functions',
'LBL_FIELD' => 'Field',
'LBL_EXPRESSION' => 'Expression',
'LBL_SETTINGS' => 'Settings',
'LBL_NEW_FIELD_EXPRESSION_BUTTON' => 'New Field Expression',
'LBL_EDIT_EXPRESSION' => 'Edit Expression',
'LBL_MODULE_INFO' => 'Custom fields in',
'NEED_TO_ADD_A' =>'You need to add a string or integer type ',
'LBL_CUSTOM_FIELD' =>'Custom field'
);

?>
