<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'Webforms' => 'Webforms',
'LBL_SUCCESS' => 'elemento aggiunto.',
'LBL_FAILURE' => 'Errore durante l\'inserimento dell\'elemento.',
'LBL_ERROR_CODE' => 'Codice Errore',
'LBL_ERROR_MESSAGE' => 'Messaggio Errore'
);

?>
