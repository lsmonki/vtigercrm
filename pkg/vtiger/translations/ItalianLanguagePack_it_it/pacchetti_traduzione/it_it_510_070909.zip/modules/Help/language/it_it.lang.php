<?php
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Azienda',
  'LBL_MODULE_TITLE' => 'Azienda: Home',
  'LBL_SEARCH_FORM_TITLE' => 'Cerca Azienda',
  'LBL_LIST_FORM_TITLE' => 'Lista Azienda',
  'LBL_NEW_FORM_TITLE' => 'Nuova Azienda',
  'ERR_DELETE_RECORD' => 'Deve essere selezionato almeno un record per poter cancellare l&#39;azienda',

);
?>