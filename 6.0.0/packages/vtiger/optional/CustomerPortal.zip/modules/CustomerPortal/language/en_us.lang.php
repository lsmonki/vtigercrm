<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'CustomerPortal',
'LBL_BASIC_SETTINGS'=>'Basic Settings',
'LBL_CUSTOMERPORTAL_SETTINGS'=>'CustomerPortal Settings',
'LBL_ADVANCED_SETTINGS'=>'Advanced Settings',
'LBL_MODULE'=>'Module',
'LBL_VIEW_ALL_RECORD'=>'View All Related Records ?',
'LBL_MODULE_INFORMATION'=>'Module Information',
'LBL_USER_INFORMATION'=>'User Information',
'LBL_YES'=>'Yes',
'LBL_NO'=>'No',
'LBL_USER_DESCRIPTION'=>'NOTE : The above selected User\'s profile will be selected to control the fields that appear in the Customer Portal.',
'LBL_GROUP_DESCRIPTION'=>'NOTE : Trouble Tickets will be Assigned to the above selected Assignee by default Group/User from the Customer Portal.',
'LBL_SELECT_USERS'=>'Users Profile',
'LBL_DEFAULT_USERS'=>'Default Assignee',
'LBL_DISABLE'=>'Disable',
'LBL_ENABLE' =>'Enable',
'LBL_MODULE' => 'Module',
'LBL_SEQUENCE' =>'Sequence',
'LBL_VISIBLE'=>'Visible'

);

?>
