<?php
/** YOUR LICENSE TEXT HERE **/
$mod_strings = Array (
'CustomerPortal' => 'Portal do Cliente',
'LBL_BASIC_SETTINGS'=>'Configurações Básicas',
'LBL_ADVANCED_SETTINGS'=>'Configurações Avançadas',
'LBL_MODULE'=>'Módulo',
'LBL_VIEW_ALL_RECORD'=>'Visualizar Todos os Registros Relacionados?',
'YES'=>'Sim',
'NO'=>'Não',
'LBL_USER_DESCRIPTION'=>'O Perfil de Usuário acima selecionado será definido para controle dos campos que aparecem no Portal do Cliente
				Você poderá habilitar/desabilitar os campos que aparecem no Portal do Cliente.',
'SELECT_USERS'=>'Selecionar Usuários',
'LBL_DISABLE'=>'Desabilitar',
'LBL_ENABLE' =>'Habilitar',
'Module' => 'Módulo',
'Sequence' =>'Sequência',
'Visible'=>'Visível'

);

?>
